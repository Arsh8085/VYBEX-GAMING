# VYBEX Gaming — project bundle

This bundle preserves the earlier website prototype and adds a Flutter cross-platform mobile UI starter for Android and iOS.

- `vybex_gaming_mobile/` — Flutter mobile UI starter (Home, Rooms, Games, Wallet, Profile)
- `vybex_gaming_website/` — earlier responsive website + Node.js/Express backend and Razorpay scaffold

Important: neither folder is a finished production gaming service. Real accounts, persistent chat, friends, voice rooms, multiplayer, 3D world, secure wallet ledger, payment webhooks, and store release setup remain future milestones. The mobile wallet is display-only; no payment action is enabled.
