# VYBEX Gaming Website — MVP Prototype

A responsive, original social-gaming landing page with demo rooms, mini-game interaction, coin packs and a Razorpay checkout integration scaffold.

## What works in this prototype
- Responsive desktop/mobile layout.
- Room and social-world preview cards.
- Lucky Tap demo.
- Selectable virtual-coin packs.
- Backend endpoint that creates Razorpay orders when merchant credentials are configured.
- Server-side payment signature verification scaffold.

## Important limitations
- This is a prototype, not a production-ready gaming service.
- No real user accounts, chat server, friend graph, live voice, multiplayer or 3D engine is connected.
- Coin balance in the browser is a demo display, not a persistent wallet ledger.
- Before production, add authentication, a database, durable wallet ledger, transaction idempotency, payment-status fetching/webhooks, rate limiting, logging, fraud controls, privacy/terms/refund policies, and security testing.
- Never credit coins based only on a browser callback. Verify payment status and amount on the server, use an idempotent ledger transaction, and reconcile via gateway webhooks.
- Do not put the Razorpay secret in frontend code or commit `.env`.
- Virtual coin packs and pricing are placeholders. Review payment-provider terms and app-store rules for digital goods before launch.
- UPI ID supplied by the owner is not hardcoded into this prototype. Use the payment gateway's verified merchant configuration rather than displaying a personal UPI handle as a substitute for secure checkout.

## Run locally
1. Install Node.js 18 or newer.
2. In this folder, run `npm install`.
3. Copy `.env.example` to `.env`.
4. Add your Razorpay **test** Key ID and Key Secret from your merchant dashboard.
5. Run `npm start`.
6. Open `http://localhost:3000`.

If keys are not configured, clicking checkout displays a safe demo-mode message and does not charge or credit coins.

## Test before live launch
- Use test credentials and the gateway's documented test payment methods.
- Confirm order creation, successful/failed/cancelled payments, invalid signatures and repeated callbacks.
- Add authenticated user IDs and a database transaction before enabling real coin credits.
- Switch to live credentials only after merchant verification and compliance review.
