const packs = {
  starter: {name:"Starter Pack", coins:1000, amount:9900},
  popular: {name:"Glow Pack", coins:5500, amount:39900},
  ultra: {name:"Galaxy Pack", coins:15000, amount:99900}
};
let selectedPack = "popular";
let demoBalance = 1200;
const balance = document.getElementById("balance");
const message = document.getElementById("paymentMessage");
const payButton = document.getElementById("payButton");
const toast = document.getElementById("toast");
document.getElementById("year").textContent = new Date().getFullYear();

function showToast(text) {
  toast.textContent = text;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("show"), 2600);
}
document.querySelectorAll(".pack").forEach(button => button.addEventListener("click", () => {
  document.querySelectorAll(".pack").forEach(p => p.classList.remove("selected"));
  button.classList.add("selected");
  selectedPack = button.dataset.pack;
  message.textContent = "";
}));
document.querySelectorAll("[data-toast]").forEach(button => button.addEventListener("click", () => showToast(button.dataset.toast)));
document.getElementById("tapGame").addEventListener("click", () => {
  const score = document.getElementById("score");
  score.textContent = String(Number(score.textContent) + 1);
});

payButton.addEventListener("click", async () => {
  message.textContent = "";
  const pack = packs[selectedPack];
  payButton.disabled = true;
  payButton.textContent = "Connecting to secure checkout…";
  try {
    const response = await fetch("/api/create-order", {
      method: "POST", headers: {"Content-Type":"application/json"},
      body: JSON.stringify({packId:selectedPack})
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Could not create payment order.");
    if (data.demo) {
      message.textContent = "Demo mode: payment provider is not configured. No money was charged and no coins were added.";
      return;
    }
    if (!window.Razorpay) throw new Error("Payment checkout could not load. Please try again.");
    const checkout = new Razorpay({
      key: data.keyId,
      amount: data.amount,
      currency: data.currency,
      name: "VYBEX",
      description: `${pack.name} — ${pack.coins.toLocaleString()} virtual coins`,
      order_id: data.orderId,
      prefill: data.prefill || {},
      theme: {color:"#8b5cf6"},
      handler: async function (result) {
        message.textContent = "Verifying payment securely…";
        const verify = await fetch("/api/verify-payment", {
          method:"POST", headers:{"Content-Type":"application/json"},
          body:JSON.stringify({...result, packId:selectedPack})
        });
        const verified = await verify.json();
        if (!verify.ok) throw new Error(verified.error || "Payment verification failed.");
        message.textContent = `Payment verified. ${pack.coins.toLocaleString()} coins credited to your demo account.`;
        demoBalance += pack.coins;
        balance.textContent = demoBalance.toLocaleString("en-IN");
      },
      modal: {ondismiss: () => {message.textContent = "Checkout closed. No coins were added.";}}
    });
    checkout.on("payment.failed", event => { message.textContent = event.error?.description || "Payment failed."; });
    checkout.open();
  } catch (error) {
    message.textContent = error.message || "Payment setup unavailable.";
  } finally {
    payButton.disabled = false;
    payButton.innerHTML = 'Continue to secure payment <span>↗</span>';
  }
});
