const express = require("express");
const Razorpay = require("razorpay");
const crypto = require("crypto");
const path = require("path");

const app = express();
app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));

const PORT = process.env.PORT || 3000;
const KEY_ID = process.env.RAZORPAY_KEY_ID;
const KEY_SECRET = process.env.RAZORPAY_KEY_SECRET;

// Server-side pack catalogue. Never trust a price or coin amount supplied by the browser.
const PACKS = {
  starter: { name: "Starter Pack", coins: 1000, amount: 9900 },
  popular: { name: "Glow Pack", coins: 5500, amount: 39900 },
  ultra: { name: "Galaxy Pack", coins: 15000, amount: 99900 }
};

function getGateway() {
  if (!KEY_ID || !KEY_SECRET) return null;
  return new Razorpay({ key_id: KEY_ID, key_secret: KEY_SECRET });
}

app.post("/api/create-order", async (req, res) => {
  try {
    const pack = PACKS[req.body?.packId];
    if (!pack) return res.status(400).json({ error: "Invalid coin pack." });
    const gateway = getGateway();
    if (!gateway) {
      return res.status(503).json({
        demo: true,
        error: "Payment gateway is not configured yet. No payment was created."
      });
    }
    const order = await gateway.orders.create({
      amount: pack.amount,
      currency: "INR",
      receipt: `vybex_${Date.now()}`,
      notes: { product: pack.name, coin_pack: req.body.packId }
    });
    res.json({ orderId: order.id, amount: order.amount, currency: order.currency, keyId: KEY_ID });
  } catch (error) {
    console.error("Order creation failed:", error.message);
    res.status(500).json({ error: "Unable to start checkout. Please try again." });
  }
});

app.post("/api/verify-payment", async (req, res) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, packId } = req.body || {};
    const pack = PACKS[packId];
    if (!pack || !razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
      return res.status(400).json({ error: "Missing payment details." });
    }
    if (!KEY_SECRET) return res.status(503).json({ error: "Payment verification is not configured." });
    const expected = crypto.createHmac("sha256", KEY_SECRET)
      .update(`${razorpay_order_id}|${razorpay_payment_id}`)
      .digest("hex");
    const a = Buffer.from(expected, "utf8");
    const b = Buffer.from(String(razorpay_signature), "utf8");
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
      return res.status(400).json({ error: "Payment signature is invalid." });
    }

    // IMPORTANT: This sample verifies the signature only. Production must also fetch
    // the payment/order from Razorpay, confirm captured status and amount/currency,
    // enforce idempotency, authenticate the user, and credit coins in a durable DB
    // transaction. Do not use this demo response as a production wallet ledger.
    res.json({ verified: true, coins: pack.coins, note: "Prototype only; connect a durable wallet ledger before launch." });
  } catch (error) {
    console.error("Payment verification failed:", error.message);
    res.status(500).json({ error: "Unable to verify payment." });
  }
});

app.get("/health", (_req, res) => res.json({ ok: true, app: "VYBEX" }));
app.listen(PORT, () => console.log(`VYBEX running on http://localhost:${PORT}`));
