# VYBEX Gaming — Flutter mobile starter

This is the first cross-platform mobile UI foundation for Android and iOS.

## Included in this stage
- Flutter app shell with Home, Rooms, Games, Wallet and Profile tabs
- Original dark neon VYBEX visual direction
- Local Lucky Tap demo interaction
- Demo coin balance and pack display (no purchases enabled)
- No external Flutter packages required for this UI starter

## Run on Android or iPhone
1. Install Flutter SDK and Android Studio (Android) or Xcode on a Mac (iOS).
2. From this folder run `flutter pub get`.
3. Run `flutter run` on an emulator or connected device.
4. To create native platform folders if needed, run `flutter create .` from this folder, then `flutter pub get` and `flutter run`.

## Not connected yet
Authentication, Firebase database, live chat, friend graph, voice rooms, multiplayer game services, 3D world, persistent wallet ledger, and payment gateway are not implemented in this UI starter. The wallet is deliberately display-only. Do not enable real-money coin sales until server-side payment capture verification, idempotent ledger crediting, account authentication, privacy/refund policies, and Google Play / Apple App Store digital-goods compliance are implemented.

## Planned build sequence
1. App foundation and navigation (this folder)
2. Authentication and player profiles (Firebase Auth)
3. Persistent profiles, friends, rooms and messages (Firestore or equivalent)
4. Voice rooms (LiveKit) with moderation and reporting controls
5. Mini-games and multiplayer service
6. 3D social world (Unity integration; separate milestone)
7. Secure server-side wallet and compliant payment integration
8. Android and iOS release builds and store testing

## Existing web prototype
The sibling `vybex_gaming_website` folder contains the earlier Node.js/Express website prototype and payment integration scaffold. It is not a production backend.
