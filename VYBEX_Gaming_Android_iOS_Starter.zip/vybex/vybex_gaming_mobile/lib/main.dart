import 'package:flutter/material.dart';

void main() => runApp(const VybexApp());

const Color vybexBg = Color(0xFF090914);
const Color vybexPanel = Color(0xFF17172A);
const Color vybexPurple = Color(0xFF9B6BFF);
const Color vybexCyan = Color(0xFF55D6FF);

class VybexApp extends StatelessWidget {
  const VybexApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'VYBEX Gaming',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: vybexBg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: vybexPurple,
          brightness: Brightness.dark,
          surface: vybexPanel,
        ),
        useMaterial3: true,
      ),
      home: const VybexShell(),
    );
  }
}

class VybexShell extends StatefulWidget {
  const VybexShell({super.key});

  @override
  State<VybexShell> createState() => _VybexShellState();
}

class _VybexShellState extends State<VybexShell> {
  int selected = 0;
  final pages = const [HomeScreen(), RoomsScreen(), GamesScreen(), WalletScreen(), ProfileScreen()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: selected, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selected,
        onDestinationSelected: (value) => setState(() => selected = value),
        backgroundColor: const Color(0xFF111120),
        indicatorColor: vybexPurple.withOpacity(.22),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_rounded), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.forum_rounded), label: 'Rooms'),
          NavigationDestination(icon: Icon(Icons.sports_esports_rounded), label: 'Games'),
          NavigationDestination(icon: Icon(Icons.diamond_rounded), label: 'Wallet'),
          NavigationDestination(icon: Icon(Icons.person_rounded), label: 'Profile'),
        ],
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(20), children: [
      Row(children: [
        Container(width: 42, height: 42, decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          gradient: const LinearGradient(colors: [vybexPurple, vybexCyan]),
        ), child: const Icon(Icons.bolt_rounded, color: Colors.white, size: 28)),
        const SizedBox(width: 12),
        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('VYBEX', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: 2)),
          Text('YOUR WORLD. YOUR PEOPLE.', style: TextStyle(fontSize: 9, color: Colors.white60, letterSpacing: 1.5)),
        ])),
        const CircleAvatar(backgroundColor: vybexPanel, child: Icon(Icons.notifications_none_rounded)),
      ]),
      const SizedBox(height: 26),
      Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF38216B), Color(0xFF152B4D)]),
      ), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('ENTER YOUR WORLD', style: TextStyle(fontSize: 12, letterSpacing: 2, color: Colors.white70)),
        const SizedBox(height: 8),
        const Text('Meet. Play.\nLevel Up.', style: TextStyle(fontSize: 32, height: 1.05, fontWeight: FontWeight.w900)),
        const SizedBox(height: 16),
        FilledButton.icon(onPressed: () {}, icon: const Icon(Icons.explore_rounded), label: const Text('Explore VYBEX')),
      ])),
      const SizedBox(height: 24),
      const SectionHeading(title: 'Discover', subtitle: 'Find your next hangout'),
      const SizedBox(height: 12),
      const Row(children: [
        Expanded(child: FeatureTile(icon: Icons.mic_rounded, title: 'Live Rooms', detail: 'Talk & connect', color: vybexPurple)),
        SizedBox(width: 12),
        Expanded(child: FeatureTile(icon: Icons.sports_esports_rounded, title: 'Mini Games', detail: 'Play together', color: vybexCyan)),
      ]),
      const SizedBox(height: 24),
      const SectionHeading(title: 'Trending rooms', subtitle: 'Community spaces'),
      const SizedBox(height: 12),
      const RoomCard(name: 'Chill Zone', members: '128 online', tag: 'SOCIAL', icon: Icons.nightlife_rounded),
      const RoomCard(name: 'Game Arena', members: '86 online', tag: 'GAMING', icon: Icons.videogame_asset_rounded),
      const SizedBox(height: 12),
      const Text('Prototype preview • Online features are being connected.', style: TextStyle(color: Colors.white38, fontSize: 11)),
    ]);
  }
}

class RoomsScreen extends StatelessWidget {
  const RoomsScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const PageTitle(title: 'Rooms', subtitle: 'Find people and hang out'),
    const SizedBox(height: 18),
    const RoomCard(name: 'Chill Zone', members: '128 online', tag: 'SOCIAL', icon: Icons.nightlife_rounded),
    const RoomCard(name: 'Game Arena', members: '86 online', tag: 'GAMING', icon: Icons.videogame_asset_rounded),
    const RoomCard(name: 'Music Lounge', members: '42 online', tag: 'MUSIC', icon: Icons.headphones_rounded),
    const RoomCard(name: 'New Friends', members: '19 online', tag: 'MEET', icon: Icons.people_alt_rounded),
  ]);
}

class GamesScreen extends StatefulWidget {
  const GamesScreen({super.key});
  @override
  State<GamesScreen> createState() => _GamesScreenState();
}
class _GamesScreenState extends State<GamesScreen> {
  int score = 0;
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const PageTitle(title: 'Mini Games', subtitle: 'Quick fun while you hang out'),
    const SizedBox(height: 18),
    Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: vybexPanel, borderRadius: BorderRadius.circular(22)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Icon(Icons.touch_app_rounded, color: vybexCyan, size: 34),
      const SizedBox(height: 10),
      const Text('Lucky Tap', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
      const Text('Tap to increase your local demo score.', style: TextStyle(color: Colors.white60)),
      const SizedBox(height: 18),
      Text('Score: $score', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: () => setState(() => score++), icon: const Icon(Icons.bolt), label: const Text('TAP NOW')),
    ])),
    const SizedBox(height: 14),
    const FeatureTile(icon: Icons.extension_rounded, title: 'More games coming', detail: 'Multiplayer games will be added in a later build', color: vybexPurple),
  ]);
}

class WalletScreen extends StatelessWidget {
  const WalletScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const PageTitle(title: 'Wallet', subtitle: 'Your VYBEX coins and gifts'),
    const SizedBox(height: 18),
    Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: const LinearGradient(colors: [Color(0xFF4A2B83), Color(0xFF17435A)])), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('DEMO BALANCE', style: TextStyle(color: Colors.white70, letterSpacing: 1.4)),
      SizedBox(height: 8),
      Row(children: [Icon(Icons.circle, color: Color(0xFFFFD36A)), SizedBox(width: 10), Text('1,200', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900))]),
      SizedBox(height: 8),
      Text('Demo coins only • no real value', style: TextStyle(color: Colors.white70, fontSize: 12)),
    ])),
    const SizedBox(height: 20),
    const Text('Coin packs', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    const SizedBox(height: 10),
    const PackTile(title: 'Starter Pack', coins: '1,000 coins', price: '₹99'),
    const PackTile(title: 'Glow Pack', coins: '5,500 coins', price: '₹399'),
    const PackTile(title: 'Galaxy Pack', coins: '15,000 coins', price: '₹999'),
    const SizedBox(height: 10),
    const Text('Purchases are disabled until secure payment verification and app-store compliance are completed.', style: TextStyle(color: Colors.white54, fontSize: 11)),
  ]);
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const PageTitle(title: 'Profile', subtitle: 'Your player identity'),
    const SizedBox(height: 28),
    const Center(child: CircleAvatar(radius: 42, backgroundColor: vybexPanel, child: Icon(Icons.person_rounded, size: 48, color: vybexCyan))),
    const SizedBox(height: 12),
    const Center(child: Text('VYBEX Player', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
    const Center(child: Text('Guest preview account', style: TextStyle(color: Colors.white54))),
    const SizedBox(height: 24),
    const FeatureTile(icon: Icons.group_add_rounded, title: 'Friends', detail: 'Friend list and invites are coming soon', color: vybexPurple),
    const SizedBox(height: 12),
    const FeatureTile(icon: Icons.settings_rounded, title: 'Settings', detail: 'Account and privacy settings will appear here', color: vybexCyan),
  ]);
}

class PageTitle extends StatelessWidget {
  final String title, subtitle;
  const PageTitle({super.key, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(title, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
    Text(subtitle, style: const TextStyle(color: Colors.white60)),
  ]);
}

class SectionHeading extends StatelessWidget {
  final String title, subtitle;
  const SectionHeading({super.key, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 12))])), const Icon(Icons.arrow_forward_ios_rounded, size: 15, color: Colors.white54)]);
}

class FeatureTile extends StatelessWidget {
  final IconData icon; final String title, detail; final Color color;
  const FeatureTile({super.key, required this.icon, required this.title, required this.detail, required this.color});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: vybexPanel, borderRadius: BorderRadius.circular(18)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: color, size: 27), const SizedBox(height: 12), Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 4), Text(detail, style: const TextStyle(color: Colors.white54, fontSize: 11))]));
}

class RoomCard extends StatelessWidget {
  final String name, members, tag; final IconData icon;
  const RoomCard({super.key, required this.name, required this.members, required this.tag, required this.icon});
  @override
  Widget build(BuildContext context) => Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: vybexPanel, borderRadius: BorderRadius.circular(18)), child: Row(children: [Container(width: 48, height: 48, decoration: BoxDecoration(color: vybexPurple.withOpacity(.18), borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: vybexCyan)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(name, style: const TextStyle(fontWeight: FontWeight.bold)), Text(members, style: const TextStyle(color: Colors.white54, fontSize: 12))])), Text(tag, style: const TextStyle(color: vybexCyan, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1))]));
}

class PackTile extends StatelessWidget {
  final String title, coins, price;
  const PackTile({super.key, required this.title, required this.coins, required this.price});
  @override
  Widget build(BuildContext context) => Container(margin: const EdgeInsets.only(bottom: 9), padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: vybexPanel, borderRadius: BorderRadius.circular(16)), child: Row(children: [const Icon(Icons.diamond_rounded, color: Color(0xFFFFD36A)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), Text(coins, style: const TextStyle(color: Colors.white54, fontSize: 12))])), Text(price, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16))]));
}
